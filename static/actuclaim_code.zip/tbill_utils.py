import os
import pandas as pd
from datetime import datetime, timedelta
import logging

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Path to the T-Bill rates Excel file with correct filename
TBILL_FILE_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data', 'TBill Rate (2022 to present).xlsx')

def load_tbill_rates():
    """
    Load T-Bill rates from Excel file
    Returns a pandas DataFrame with dates and rates
    """
    try:
        # Read the Excel file
        df = pd.read_excel(TBILL_FILE_PATH)
        
        # Ensure column names are as expected
        if 'Date' not in df.columns or 'T-Bill Rate' not in df.columns:
            column_names = df.columns.tolist()
            # If column names don't match, try to rename them
            if len(column_names) >= 2:
                df = df.rename(columns={column_names[0]: 'Date', column_names[1]: 'T-Bill Rate'})
            else:
                logger.error(f"Unexpected Excel structure. Columns: {column_names}")
                return None
        
        # Convert Date column to datetime
        df['Date'] = pd.to_datetime(df['Date'])
        
	# Convert T-Bill Rate to float, handling non-numeric values
        df['T-Bill Rate'] = pd.to_numeric(df['T-Bill Rate'], errors='coerce')
        # Drop rows with NaN values (which were non-numeric)
        df = df.dropna(subset=['T-Bill Rate'])
        
        # Sort by date
        df = df.sort_values('Date')
        
        logger.info(f"Successfully loaded {len(df)} T-Bill rates")
        return df
    
    except Exception as e:
        logger.error(f"Error loading T-Bill rates: {str(e)}")
        return None

def get_average_tbill_rate(start_date, end_date=None):
    """
    Calculate the average T-Bill rate between start_date and end_date
    
    Args:
        start_date (str or datetime): Date of loss in 'YYYY-MM-DD' format or datetime object
        end_date (str or datetime, optional): Date of calculation, defaults to today
        
    Returns:
        float: Average T-Bill rate, or None if calculation fails
    """
    try:
        # Convert string dates to datetime if necessary
        if isinstance(start_date, str):
            start_date = datetime.strptime(start_date, '%Y-%m-%d')
        
        if end_date is None:
            end_date = datetime.now()
        elif isinstance(end_date, str):
            end_date = datetime.strptime(end_date, '%Y-%m-%d')
        
        # Load T-Bill rates
        rates_df = load_tbill_rates()
        if rates_df is None:
            logger.error("Failed to load T-Bill rates")
            return None
        
        # Filter rates between start_date and end_date
        mask = (rates_df['Date'] >= start_date) & (rates_df['Date'] <= end_date)
        filtered_df = rates_df[mask]
        
        if filtered_df.empty:
            logger.warning(f"No T-Bill rates found between {start_date} and {end_date}")
            
            # Use the closest available rate as a fallback
            if start_date < rates_df['Date'].min():
                # If start_date is before earliest available rate, use earliest rate
                closest_rate = rates_df.iloc[0]['T-Bill Rate']
                logger.info(f"Using earliest available rate: {closest_rate}")
                return closest_rate
            elif end_date > rates_df['Date'].max():
                # If end_date is after latest available rate, use latest rate
                closest_rate = rates_df.iloc[-1]['T-Bill Rate']
                logger.info(f"Using latest available rate: {closest_rate}")
                return closest_rate
            
            return None
        
        # Calculate average rate
        avg_rate = filtered_df['T-Bill Rate'].mean()
        logger.info(f"Average T-Bill rate between {start_date.date()} and {end_date.date()}: {avg_rate:.2f}%")
        
        return round(avg_rate, 2)
    
    except Exception as e:
        logger.error(f"Error calculating average T-Bill rate: {str(e)}")
        return None

# Example usage
if __name__ == "__main__":
    # Test the function with a sample date range
    avg_rate = get_average_tbill_rate('2022-04-01', '2022-06-30')
    print(f"Average T-Bill rate: {avg_rate}%")
